# Promo Admin Template

A full landing-page template with admin panel.

## Features
- Admin login
- Hero banner settings
- Theme colors
- Promotion cards CRUD
- FAQ CRUD
- SQLite database
- Image upload or image URL
- Frontend auto-reads admin data

## Quick start

```bash
npm install
copy .env.example .env
npm start
```

Open:
- Website: http://localhost:3000
- Admin: http://localhost:3000/admin/login

Default admin:
- username: admin
- password: 123456

## Deploy to Railway
1. Upload project to GitHub
2. Create Railway project from GitHub repo
3. Add environment variables from `.env.example`
4. Deploy

## Notes
- Uploaded images are stored in `/public/uploads`
- SQLite database file is `site.db`
- Change admin password before production
