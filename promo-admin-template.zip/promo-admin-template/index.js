require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const helmet = require('helmet');
const multer = require('multer');
const fs = require('fs');
const { db, initDb, getSettings, updateSettings } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '123456';
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-this-secret-key';

initDb();

const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  }
});
const upload = multer({ storage });

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax' }
}));

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.redirect('/admin/login');
}

function resolveImageUrl(file, imageUrl) {
  if (file) return `/uploads/${file.filename}`;
  return imageUrl || '';
}

app.get('/', (req, res) => {
  const settings = getSettings();
  const cards = db.prepare('SELECT * FROM cards WHERE active = 1 ORDER BY sort_order ASC, id DESC').all();
  const faqs = db.prepare('SELECT * FROM faqs WHERE active = 1 ORDER BY sort_order ASC, id DESC').all();
  res.render('home', { settings, cards, faqs });
});

app.get('/admin/login', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/admin');
  res.render('login', { error: null });
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    return res.redirect('/admin');
  }
  res.status(401).render('login', { error: 'Invalid username or password' });
});

app.get('/admin/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

app.get('/admin', requireAdmin, (req, res) => {
  const settings = getSettings();
  const cards = db.prepare('SELECT * FROM cards ORDER BY sort_order ASC, id DESC').all();
  const faqs = db.prepare('SELECT * FROM faqs ORDER BY sort_order ASC, id DESC').all();
  res.render('admin/dashboard', { settings, cards, faqs, message: req.query.message || '' });
});

app.post('/admin/settings', requireAdmin, upload.single('hero_image_file'), (req, res) => {
  const nextSettings = {
    site_name: req.body.site_name,
    site_tagline: req.body.site_tagline,
    logo_text: req.body.logo_text,
    primary_color: req.body.primary_color,
    secondary_color: req.body.secondary_color,
    accent_color: req.body.accent_color,
    hero_title: req.body.hero_title,
    hero_subtitle: req.body.hero_subtitle,
    hero_button_1_text: req.body.hero_button_1_text,
    hero_button_1_link: req.body.hero_button_1_link,
    hero_button_2_text: req.body.hero_button_2_text,
    hero_button_2_link: req.body.hero_button_2_link,
    hero_image: resolveImageUrl(req.file, req.body.hero_image),
    top_notice: req.body.top_notice,
    footer_text: req.body.footer_text,
    contact_whatsapp: req.body.contact_whatsapp,
    contact_telegram: req.body.contact_telegram,
    contact_email: req.body.contact_email
  };
  updateSettings(nextSettings);
  res.redirect('/admin?message=Settings%20updated');
});

app.post('/admin/cards', requireAdmin, upload.single('image_file'), (req, res) => {
  const imageUrl = resolveImageUrl(req.file, req.body.image_url);
  db.prepare(`
    INSERT INTO cards (title, subtitle, bonus, daily_promo, pros, cons, button_text, button_link, image_url, sort_order, active)
    VALUES (@title, @subtitle, @bonus, @daily_promo, @pros, @cons, @button_text, @button_link, @image_url, @sort_order, @active)
  `).run({
    title: req.body.title,
    subtitle: req.body.subtitle || '',
    bonus: req.body.bonus || '',
    daily_promo: req.body.daily_promo || '',
    pros: req.body.pros || '',
    cons: req.body.cons || '',
    button_text: req.body.button_text || 'Join Now',
    button_link: req.body.button_link || '#',
    image_url: imageUrl,
    sort_order: Number(req.body.sort_order || 0),
    active: Number(req.body.active || 1)
  });
  res.redirect('/admin?message=Card%20added');
});

app.post('/admin/cards/:id/update', requireAdmin, upload.single('image_file'), (req, res) => {
  const current = db.prepare('SELECT * FROM cards WHERE id = ?').get(req.params.id);
  const imageUrl = req.file ? resolveImageUrl(req.file) : (req.body.image_url || current.image_url);
  db.prepare(`
    UPDATE cards SET
      title=@title,
      subtitle=@subtitle,
      bonus=@bonus,
      daily_promo=@daily_promo,
      pros=@pros,
      cons=@cons,
      button_text=@button_text,
      button_link=@button_link,
      image_url=@image_url,
      sort_order=@sort_order,
      active=@active
    WHERE id=@id
  `).run({
    id: Number(req.params.id),
    title: req.body.title,
    subtitle: req.body.subtitle || '',
    bonus: req.body.bonus || '',
    daily_promo: req.body.daily_promo || '',
    pros: req.body.pros || '',
    cons: req.body.cons || '',
    button_text: req.body.button_text || 'Join Now',
    button_link: req.body.button_link || '#',
    image_url: imageUrl,
    sort_order: Number(req.body.sort_order || 0),
    active: Number(req.body.active || 1)
  });
  res.redirect('/admin?message=Card%20updated');
});

app.post('/admin/cards/:id/delete', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM cards WHERE id = ?').run(req.params.id);
  res.redirect('/admin?message=Card%20deleted');
});

app.post('/admin/faqs', requireAdmin, (req, res) => {
  db.prepare('INSERT INTO faqs (question, answer, sort_order, active) VALUES (?, ?, ?, ?)')
    .run(req.body.question, req.body.answer, Number(req.body.sort_order || 0), Number(req.body.active || 1));
  res.redirect('/admin?message=FAQ%20added');
});

app.post('/admin/faqs/:id/update', requireAdmin, (req, res) => {
  db.prepare('UPDATE faqs SET question=?, answer=?, sort_order=?, active=? WHERE id=?')
    .run(req.body.question, req.body.answer, Number(req.body.sort_order || 0), Number(req.body.active || 1), req.params.id);
  res.redirect('/admin?message=FAQ%20updated');
});

app.post('/admin/faqs/:id/delete', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM faqs WHERE id = ?').run(req.params.id);
  res.redirect('/admin?message=FAQ%20deleted');
});

app.listen(PORT, () => {
  console.log(`Server running: http://localhost:${PORT}`);
});
