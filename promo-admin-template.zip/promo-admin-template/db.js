const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'site.db'));
db.pragma('journal_mode = WAL');

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS cards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      subtitle TEXT DEFAULT '',
      bonus TEXT DEFAULT '',
      daily_promo TEXT DEFAULT '',
      pros TEXT DEFAULT '',
      cons TEXT DEFAULT '',
      button_text TEXT DEFAULT 'Join Now',
      button_link TEXT DEFAULT '#',
      image_url TEXT DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS faqs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const defaults = {
    site_name: 'My Promo Hub',
    site_tagline: 'Best deals, bonuses and promotions updated daily.',
    logo_text: 'PROMO HUB',
    primary_color: '#b71c1c',
    secondary_color: '#111111',
    accent_color: '#f6c343',
    hero_title: 'Claim Today\'s Best Promotions',
    hero_subtitle: 'A powerful landing page with admin panel. You can change banners, cards, links, colors and FAQ anytime.',
    hero_button_1_text: 'Get Bonus',
    hero_button_1_link: '#cards',
    hero_button_2_text: 'Contact Us',
    hero_button_2_link: '#footer',
    hero_image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
    top_notice: 'Trusted promotions • Mobile friendly • Easy to manage',
    footer_text: '© 2026 My Promo Hub. All rights reserved.',
    contact_whatsapp: 'https://wa.me/60123456789',
    contact_telegram: 'https://t.me/yourusername',
    contact_email: 'hello@example.com'
  };

  const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  Object.entries(defaults).forEach(([key, value]) => insertSetting.run(key, value));

  const cardCount = db.prepare('SELECT COUNT(*) as count FROM cards').get().count;
  if (cardCount === 0) {
    const insertCard = db.prepare(`
      INSERT INTO cards
      (title, subtitle, bonus, daily_promo, pros, cons, button_text, button_link, image_url, sort_order, active)
      VALUES
      (@title, @subtitle, @bonus, @daily_promo, @pros, @cons, @button_text, @button_link, @image_url, @sort_order, @active)
    `);

    const demoCards = [
      {
        title: 'Brand One',
        subtitle: 'Popular Choice',
        bonus: 'Welcome Bonus: RM188',
        daily_promo: 'Daily Promo: Cashback up to 20%',
        pros: 'Fast signup, easy mobile access, strong promotion',
        cons: 'Limited time offer',
        button_text: 'Join Brand One',
        button_link: '#',
        image_url: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=800&q=80',
        sort_order: 1,
        active: 1
      },
      {
        title: 'Brand Two',
        subtitle: 'Editor Pick',
        bonus: 'Free Credit: RM88',
        daily_promo: 'Daily Promo: Lucky spin + rewards',
        pros: 'Strong visuals, easy registration, daily updates',
        cons: 'Promo may change weekly',
        button_text: 'View Offer',
        button_link: '#',
        image_url: 'https://images.unsplash.com/photo-1556745757-8d76bdb6984b?auto=format&fit=crop&w=800&q=80',
        sort_order: 2,
        active: 1
      },
      {
        title: 'Brand Three',
        subtitle: 'Hot Promotion',
        bonus: 'No Deposit Bonus Available',
        daily_promo: 'Daily Promo: Reload rebate',
        pros: 'Beginner friendly, clean UI, clear CTA buttons',
        cons: 'Offer depends on campaign',
        button_text: 'Claim Now',
        button_link: '#',
        image_url: 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=800&q=80',
        sort_order: 3,
        active: 1
      }
    ];

    demoCards.forEach(card => insertCard.run(card));
  }

  const faqCount = db.prepare('SELECT COUNT(*) as count FROM faqs').get().count;
  if (faqCount === 0) {
    const insertFaq = db.prepare('INSERT INTO faqs (question, answer, sort_order, active) VALUES (?, ?, ?, ?)');
    insertFaq.run('How do I change the banner?', 'Login to admin panel and update the Hero section settings.', 1, 1);
    insertFaq.run('Can I change button links?', 'Yes. Every card and hero button has its own editable link field.', 2, 1);
    insertFaq.run('Can I upload my own image?', 'Yes. In admin, you can either upload an image file or paste an image URL.', 3, 1);
  }
}

function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return rows.reduce((acc, row) => {
    acc[row.key] = row.value;
    return acc;
  }, {});
}

function updateSettings(data) {
  const stmt = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  const tx = db.transaction((entries) => {
    entries.forEach(([key, value]) => stmt.run(key, value ?? ''));
  });
  tx(Object.entries(data));
}

module.exports = {
  db,
  initDb,
  getSettings,
  updateSettings
};
