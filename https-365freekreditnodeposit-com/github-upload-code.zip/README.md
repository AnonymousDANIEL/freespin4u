# Free Credit Landing Page

This project contains the landing page, local admin page, and secure Node.js server.

## Run Locally

```bash
npm start
```

The secure server reads `.env` locally.

## Required Environment Variables

Set these in Railway or your hosting server:

```text
ADMIN_USER=your_admin_username
ADMIN_PASSWORD=your_admin_password
SESSION_SECRET=long_random_secret
CLOUDFLARE_API_TOKEN=your_cloudflare_api_token
```

Optional:

```text
CLOUDFLARE_ZONE_ID=
CLOUDFLARE_ZONE_NAME=
```

## Security

Do not upload `.env` to GitHub. Use `.env.example` as a template only.

## Pages

- Front page: `/`
- Admin page: `/admin.html`

